import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  authenticateToken, 
  requireRole, 
  loginUser, 
  hashPassword,
  createFounderIfNotExists,
  type AuthRequest 
} from "./auth";
import { initializeWebSocket, getWebSocketManager } from "./websocket";
import { 
  insertAdminRequestSchema,
  insertUserSchema,
  insertCommitteeSchema,
  insertDelegateSchema,
  insertVotingSessionSchema,
  insertVoteSchema,
  insertAuditLogSchema
} from "@shared/schema";
import { z } from "zod";

const loginSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize founder user
  await createFounderIfNotExists();

  // Authentication routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      
      const result = await loginUser(username, password);
      if (!result) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Log successful login
      await storage.createAuditLog({
        userId: result.user.id,
        action: "login",
        details: { success: true },
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });

      res.json({
        user: {
          id: result.user.id,
          username: result.user.username,
          email: result.user.email,
          role: result.user.role,
          fullName: result.user.fullName
        },
        token: result.token
      });
    } catch (error) {
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  app.get("/api/auth/me", authenticateToken, (req: AuthRequest, res) => {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    res.json({
      id: req.user.id,
      username: req.user.username,
      email: req.user.email,
      role: req.user.role,
      fullName: req.user.fullName
    });
  });

  // Admin request routes
  app.post("/api/admin-requests", async (req, res) => {
    try {
      const requestData = insertAdminRequestSchema.parse(req.body);
      
      const adminRequest = await storage.createAdminRequest(requestData);
      
      // Log admin request
      await storage.createAuditLog({
        action: "admin_request_created",
        entityType: "admin_request",
        entityId: adminRequest.id,
        details: { email: requestData.email },
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });

      // Notify founder via WebSocket
      const wsManager = getWebSocketManager();
      if (wsManager) {
        wsManager.notifyAdmins({
          type: 'new_admin_request',
          data: { requestId: adminRequest.id, email: requestData.email }
        });
      }

      res.status(201).json(adminRequest);
    } catch (error) {
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  app.get("/api/admin-requests", authenticateToken, requireRole("founder"), async (req: AuthRequest, res) => {
    try {
      const status = req.query.status as string;
      const requests = await storage.getAdminRequests(status);
      res.json(requests);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch admin requests" });
    }
  });

  app.patch("/api/admin-requests/:id", authenticateToken, requireRole("founder"), async (req: AuthRequest, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status, reviewFeedback } = req.body;
      
      const updates = {
        status,
        reviewFeedback,
        reviewedBy: req.user!.id,
        reviewedAt: new Date()
      };

      const updatedRequest = await storage.updateAdminRequest(id, updates);
      if (!updatedRequest) {
        return res.status(404).json({ message: "Admin request not found" });
      }

      // If approved, create admin user
      if (status === 'approved') {
        const hashedPassword = await hashPassword('temp123'); // Temporary password
        const adminUser = await storage.createUser({
          username: updatedRequest.email.split('@')[0],
          email: updatedRequest.email,
          password: hashedPassword,
          role: 'admin',
          fullName: updatedRequest.fullName,
          isActive: true
        });

        // Log admin creation
        await storage.createAuditLog({
          userId: req.user!.id,
          action: "admin_created",
          entityType: "user",
          entityId: adminUser.id,
          details: { approvedRequestId: id, adminEmail: updatedRequest.email },
          ipAddress: req.ip,
          userAgent: req.get('User-Agent')
        });
      }

      // Log review action
      await storage.createAuditLog({
        userId: req.user!.id,
        action: "admin_request_reviewed",
        entityType: "admin_request",
        entityId: id,
        details: { status, feedback: reviewFeedback },
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });

      res.json(updatedRequest);
    } catch (error) {
      res.status(500).json({ message: "Failed to update admin request" });
    }
  });

  // Committee routes
  app.post("/api/committees", authenticateToken, requireRole("admin", "founder"), async (req: AuthRequest, res) => {
    try {
      const committeeData = insertCommitteeSchema.parse({
        ...req.body,
        adminId: req.user!.id
      });
      
      const committee = await storage.createCommittee(committeeData);
      
      await storage.createAuditLog({
        userId: req.user!.id,
        action: "committee_created",
        entityType: "committee",
        entityId: committee.id,
        details: { name: committee.name },
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });

      res.status(201).json(committee);
    } catch (error) {
      res.status(400).json({ message: "Invalid committee data" });
    }
  });

  app.get("/api/committees", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const adminId = req.user!.role === 'admin' ? req.user!.id : undefined;
      const committees = await storage.getCommittees(adminId);
      res.json(committees);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch committees" });
    }
  });

  // Delegate routes
  app.post("/api/delegates", authenticateToken, requireRole("admin", "founder"), async (req: AuthRequest, res) => {
    try {
      const { username, email, password, fullName, committeeId, country, position } = req.body;
      
      // Create user first
      const hashedPassword = await hashPassword(password);
      const user = await storage.createUser({
        username,
        email,
        password: hashedPassword,
        role: 'delegate',
        fullName,
        isActive: true
      });

      // Create delegate record
      const delegate = await storage.createDelegate({
        userId: user.id,
        committeeId,
        country,
        position,
        isActive: true
      });

      await storage.createAuditLog({
        userId: req.user!.id,
        action: "delegate_created",
        entityType: "delegate",
        entityId: delegate.id,
        details: { country, committee: committeeId },
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });

      res.status(201).json({ user, delegate });
    } catch (error) {
      res.status(400).json({ message: "Invalid delegate data" });
    }
  });

  app.get("/api/delegates", authenticateToken, requireRole("admin", "founder"), async (req: AuthRequest, res) => {
    try {
      const committeeId = req.query.committeeId ? parseInt(req.query.committeeId as string) : undefined;
      const delegates = await storage.getDelegates(committeeId);
      
      // Fetch user details for each delegate
      const delegatesWithUsers = await Promise.all(
        delegates.map(async (delegate) => {
          const user = await storage.getUser(delegate.userId);
          return { ...delegate, user };
        })
      );

      res.json(delegatesWithUsers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch delegates" });
    }
  });

  app.get("/api/delegates/me", authenticateToken, requireRole("delegate"), async (req: AuthRequest, res) => {
    try {
      const delegate = await storage.getDelegateByUserId(req.user!.id);
      if (!delegate) {
        return res.status(404).json({ message: "Delegate profile not found" });
      }

      const committee = await storage.getCommittee(delegate.committeeId);
      const stats = await storage.getDelegateStats(delegate.id);

      res.json({ delegate, committee, stats });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch delegate profile" });
    }
  });

  // Voting session routes
  app.post("/api/voting-sessions", authenticateToken, requireRole("admin", "founder"), async (req: AuthRequest, res) => {
    try {
      const sessionData = insertVotingSessionSchema.parse({
        ...req.body,
        adminId: req.user!.id
      });
      
      const session = await storage.createVotingSession(sessionData);
      
      await storage.createAuditLog({
        userId: req.user!.id,
        action: "voting_session_created",
        entityType: "voting_session",
        entityId: session.id,
        details: { title: session.title, committee: session.committeeId },
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });

      // Notify committee members via WebSocket
      const wsManager = getWebSocketManager();
      if (wsManager) {
        wsManager.broadcastVotingSessionUpdate(session.committeeId, {
          sessionId: session.id,
          title: session.title,
          status: 'started'
        });
      }

      res.status(201).json(session);
    } catch (error) {
      res.status(400).json({ message: "Invalid voting session data" });
    }
  });

  app.get("/api/voting-sessions", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const committeeId = req.query.committeeId ? parseInt(req.query.committeeId as string) : undefined;
      const status = req.query.status as string;
      
      const sessions = await storage.getVotingSessions(committeeId, status);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch voting sessions" });
    }
  });

  app.patch("/api/voting-sessions/:id", authenticateToken, requireRole("admin", "founder"), async (req: AuthRequest, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      if (updates.status === 'completed') {
        updates.endTime = new Date();
      }

      const session = await storage.updateVotingSession(id, updates);
      if (!session) {
        return res.status(404).json({ message: "Voting session not found" });
      }

      await storage.createAuditLog({
        userId: req.user!.id,
        action: "voting_session_updated",
        entityType: "voting_session",
        entityId: id,
        details: updates,
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });

      // Notify committee members
      const wsManager = getWebSocketManager();
      if (wsManager) {
        wsManager.broadcastVotingSessionUpdate(session.committeeId, {
          sessionId: session.id,
          title: session.title,
          status: session.status
        });
      }

      res.json(session);
    } catch (error) {
      res.status(500).json({ message: "Failed to update voting session" });
    }
  });

  // Vote routes
  app.post("/api/votes", authenticateToken, requireRole("delegate"), async (req: AuthRequest, res) => {
    try {
      const delegate = await storage.getDelegateByUserId(req.user!.id);
      if (!delegate) {
        return res.status(404).json({ message: "Delegate profile not found" });
      }

      const { sessionId, voteType } = insertVoteSchema.parse(req.body);
      
      // Check if already voted
      const existingVote = await storage.getVoteByDelegateAndSession(delegate.id, sessionId);
      if (existingVote) {
        return res.status(400).json({ message: "Vote already cast for this session" });
      }

      // Check if session is active
      const session = await storage.getVotingSession(sessionId);
      if (!session || session.status !== 'active') {
        return res.status(400).json({ message: "Voting session is not active" });
      }

      const vote = await storage.createVote({
        sessionId,
        delegateId: delegate.id,
        voteType
      });

      await storage.createAuditLog({
        userId: req.user!.id,
        action: "vote_cast",
        entityType: "vote",
        entityId: vote.id,
        details: { sessionId, voteType, country: delegate.country },
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });

      res.status(201).json(vote);
    } catch (error) {
      res.status(400).json({ message: "Invalid vote data" });
    }
  });

  app.get("/api/voting-sessions/:id/stats", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const sessionId = parseInt(req.params.id);
      const stats = await storage.getVotingStats(sessionId);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch voting stats" });
    }
  });

  app.get("/api/voting-sessions/:id/votes", authenticateToken, requireRole("admin", "founder"), async (req: AuthRequest, res) => {
    try {
      const sessionId = parseInt(req.params.id);
      const votes = await storage.getVotes(sessionId);
      
      // Add delegate details
      const votesWithDelegates = await Promise.all(
        votes.map(async (vote) => {
          const delegate = await storage.getDelegate(vote.delegateId);
          return { ...vote, delegate };
        })
      );

      res.json(votesWithDelegates);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch votes" });
    }
  });

  // Audit log routes
  app.get("/api/audit-logs", authenticateToken, requireRole("founder"), async (req: AuthRequest, res) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      
      const logs = await storage.getAuditLogs(userId, limit);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch audit logs" });
    }
  });

  // Statistics routes
  app.get("/api/stats/dashboard", authenticateToken, requireRole("founder"), async (req: AuthRequest, res) => {
    try {
      const pendingRequests = await storage.getAdminRequests('pending');
      const allCommittees = await storage.getCommittees();
      const allDelegates = await storage.getDelegates();
      const activeSessions = await storage.getVotingSessions(undefined, 'active');

      const stats = {
        pendingRequests: pendingRequests.length,
        activeAdmins: allCommittees.length, // Simplified - each committee has an admin
        totalDelegates: allDelegates.length,
        activeSessions: activeSessions.length
      };

      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  const httpServer = createServer(app);
  
  // Initialize WebSocket
  initializeWebSocket(httpServer);

  return httpServer;
}
