import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import type { Request, Response, NextFunction } from 'express';
import { storage } from './storage';
import type { User } from '@shared/schema';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
const SALT_ROUNDS = 12;

export interface AuthRequest extends Request {
  user?: User;
}

export interface JWTPayload {
  userId: number;
  username: string;
  email: string;
  role: string;
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function generateToken(user: User): string {
  const payload: JWTPayload = {
    userId: user.id,
    username: user.username,
    email: user.email,
    role: user.role
  };
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '24h' });
}

export function verifyToken(token: string): JWTPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as JWTPayload;
  } catch (error) {
    return null;
  }
}

export async function authenticateToken(req: AuthRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  const payload = verifyToken(token);
  if (!payload) {
    return res.status(403).json({ message: 'Invalid or expired token' });
  }

  const user = await storage.getUser(payload.userId);
  if (!user || !user.isActive) {
    return res.status(403).json({ message: 'User not found or inactive' });
  }

  req.user = user;
  next();
}

export function requireRole(...roles: string[]) {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ message: 'Authentication required' });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'Insufficient permissions' });
    }

    next();
  };
}

export async function loginUser(username: string, password: string): Promise<{ user: User; token: string } | null> {
  const user = await storage.getUserByUsername(username);
  if (!user || !user.isActive) {
    return null;
  }

  const isValid = await verifyPassword(password, user.password);
  if (!isValid) {
    return null;
  }

  // Update last login
  await storage.updateUser(user.id, { lastLogin: new Date() });

  const token = generateToken(user);
  return { user, token };
}

export async function createFounderIfNotExists(): Promise<void> {
  const founder = await storage.getUserByUsername('founder');
  if (!founder) {
    const hashedPassword = await hashPassword('founder123');
    await storage.createUser({
      username: 'founder',
      email: 'thecreeper8383@gmail.com',
      password: hashedPassword,
      role: 'founder',
      fullName: 'Shaurya Ghulati',
      isActive: true
    });
    console.log('Founder user created with username: founder, password: founder123');
  } else {
    console.log('Founder user already exists with username: founder');
  }

  // Create sample admin and delegate users for testing
  const admin = await storage.getUserByUsername('admin1');
  if (!admin) {
    const hashedPassword = await hashPassword('admin123');
    const adminUser = await storage.createUser({
      username: 'admin1',
      email: 'admin@example.com',
      password: hashedPassword,
      role: 'admin',
      fullName: 'Admin User',
      isActive: true
    });

    // Create a sample committee
    const committee = await storage.createCommittee({
      name: 'United Nations Security Council',
      abbreviation: 'UNSC',
      description: 'The Security Council of the United Nations',
      adminId: adminUser.id,
      isActive: true
    });

    console.log('Sample admin and committee created');
  }

  const delegate = await storage.getUserByUsername('delegate1');
  if (!delegate) {
    const hashedPassword = await hashPassword('delegate123');
    const delegateUser = await storage.createUser({
      username: 'delegate1',
      email: 'delegate@example.com',
      password: hashedPassword,
      role: 'delegate',
      fullName: 'Delegate User',
      isActive: true
    });

    // Get the committee to assign delegate
    const committees = await storage.getCommittees();
    if (committees.length > 0) {
      await storage.createDelegate({
        userId: delegateUser.id,
        committeeId: committees[0].id,
        country: 'United States',
        position: 'Ambassador',
        isActive: true
      });
    }

    console.log('Sample delegate created');
  }
}
