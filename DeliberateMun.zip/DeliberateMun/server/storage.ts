import { 
  users, 
  adminRequests, 
  committees, 
  delegates, 
  votingSessions, 
  votes, 
  auditLogs,
  type User, 
  type InsertUser,
  type AdminRequest,
  type InsertAdminRequest,
  type Committee,
  type InsertCommittee,
  type Delegate,
  type InsertDelegate,
  type VotingSession,
  type InsertVotingSession,
  type Vote,
  type InsertVote,
  type AuditLog,
  type InsertAuditLog
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

export interface IStorage {
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  
  // Admin request management
  createAdminRequest(request: InsertAdminRequest): Promise<AdminRequest>;
  getAdminRequests(status?: string): Promise<AdminRequest[]>;
  getAdminRequest(id: number): Promise<AdminRequest | undefined>;
  updateAdminRequest(id: number, updates: Partial<AdminRequest>): Promise<AdminRequest | undefined>;
  
  // Committee management
  createCommittee(committee: InsertCommittee): Promise<Committee>;
  getCommittees(adminId?: number): Promise<Committee[]>;
  getCommittee(id: number): Promise<Committee | undefined>;
  updateCommittee(id: number, updates: Partial<Committee>): Promise<Committee | undefined>;
  deleteCommittee(id: number): Promise<boolean>;
  
  // Delegate management
  createDelegate(delegate: InsertDelegate): Promise<Delegate>;
  getDelegates(committeeId?: number): Promise<Delegate[]>;
  getDelegate(id: number): Promise<Delegate | undefined>;
  getDelegateByUserId(userId: number): Promise<Delegate | undefined>;
  updateDelegate(id: number, updates: Partial<Delegate>): Promise<Delegate | undefined>;
  deleteDelegate(id: number): Promise<boolean>;
  
  // Voting session management
  createVotingSession(session: InsertVotingSession): Promise<VotingSession>;
  getVotingSessions(committeeId?: number, status?: string): Promise<VotingSession[]>;
  getVotingSession(id: number): Promise<VotingSession | undefined>;
  updateVotingSession(id: number, updates: Partial<VotingSession>): Promise<VotingSession | undefined>;
  
  // Vote management
  createVote(vote: InsertVote): Promise<Vote>;
  getVotes(sessionId: number): Promise<Vote[]>;
  getVoteByDelegateAndSession(delegateId: number, sessionId: number): Promise<Vote | undefined>;
  
  // Audit logging
  createAuditLog(log: InsertAuditLog): Promise<AuditLog>;
  getAuditLogs(userId?: number, limit?: number): Promise<AuditLog[]>;
  
  // Statistics
  getVotingStats(sessionId: number): Promise<{ yes: number; no: number; abstain: number; total: number; }>;
  getDelegateStats(delegateId: number): Promise<{ totalVotes: number; participationRate: number; }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async createAdminRequest(request: InsertAdminRequest): Promise<AdminRequest> {
    const [adminRequest] = await db
      .insert(adminRequests)
      .values(request)
      .returning();
    return adminRequest;
  }

  async getAdminRequests(status?: string): Promise<AdminRequest[]> {
    const query = db.select().from(adminRequests);
    if (status) {
      return await query.where(eq(adminRequests.status, status)).orderBy(desc(adminRequests.createdAt));
    }
    return await query.orderBy(desc(adminRequests.createdAt));
  }

  async getAdminRequest(id: number): Promise<AdminRequest | undefined> {
    const [request] = await db.select().from(adminRequests).where(eq(adminRequests.id, id));
    return request || undefined;
  }

  async updateAdminRequest(id: number, updates: Partial<AdminRequest>): Promise<AdminRequest | undefined> {
    const [request] = await db
      .update(adminRequests)
      .set(updates)
      .where(eq(adminRequests.id, id))
      .returning();
    return request || undefined;
  }

  async createCommittee(committee: InsertCommittee): Promise<Committee> {
    const [newCommittee] = await db
      .insert(committees)
      .values(committee)
      .returning();
    return newCommittee;
  }

  async getCommittees(adminId?: number): Promise<Committee[]> {
    if (adminId) {
      return await db.select().from(committees).where(and(eq(committees.adminId, adminId), eq(committees.isActive, true)));
    }
    return await db.select().from(committees).where(eq(committees.isActive, true));
  }

  async getCommittee(id: number): Promise<Committee | undefined> {
    const [committee] = await db.select().from(committees).where(eq(committees.id, id));
    return committee || undefined;
  }

  async updateCommittee(id: number, updates: Partial<Committee>): Promise<Committee | undefined> {
    const [committee] = await db
      .update(committees)
      .set(updates)
      .where(eq(committees.id, id))
      .returning();
    return committee || undefined;
  }

  async deleteCommittee(id: number): Promise<boolean> {
    const [committee] = await db
      .update(committees)
      .set({ isActive: false })
      .where(eq(committees.id, id))
      .returning();
    return !!committee;
  }

  async createDelegate(delegate: InsertDelegate): Promise<Delegate> {
    const [newDelegate] = await db
      .insert(delegates)
      .values(delegate)
      .returning();
    return newDelegate;
  }

  async getDelegates(committeeId?: number): Promise<Delegate[]> {
    if (committeeId) {
      return await db.select().from(delegates).where(and(eq(delegates.committeeId, committeeId), eq(delegates.isActive, true)));
    }
    return await db.select().from(delegates).where(eq(delegates.isActive, true));
  }

  async getDelegate(id: number): Promise<Delegate | undefined> {
    const [delegate] = await db.select().from(delegates).where(eq(delegates.id, id));
    return delegate || undefined;
  }

  async getDelegateByUserId(userId: number): Promise<Delegate | undefined> {
    const [delegate] = await db.select().from(delegates).where(and(eq(delegates.userId, userId), eq(delegates.isActive, true)));
    return delegate || undefined;
  }

  async updateDelegate(id: number, updates: Partial<Delegate>): Promise<Delegate | undefined> {
    const [delegate] = await db
      .update(delegates)
      .set(updates)
      .where(eq(delegates.id, id))
      .returning();
    return delegate || undefined;
  }

  async deleteDelegate(id: number): Promise<boolean> {
    const [delegate] = await db
      .update(delegates)
      .set({ isActive: false })
      .where(eq(delegates.id, id))
      .returning();
    return !!delegate;
  }

  async createVotingSession(session: InsertVotingSession): Promise<VotingSession> {
    const [newSession] = await db
      .insert(votingSessions)
      .values(session)
      .returning();
    return newSession;
  }

  async getVotingSessions(committeeId?: number, status?: string): Promise<VotingSession[]> {
    let query = db.select().from(votingSessions).orderBy(desc(votingSessions.createdAt));
    
    if (committeeId && status) {
      return await query.where(and(eq(votingSessions.committeeId, committeeId), eq(votingSessions.status, status)));
    } else if (committeeId) {
      return await query.where(eq(votingSessions.committeeId, committeeId));
    } else if (status) {
      return await query.where(eq(votingSessions.status, status));
    }
    
    return await query;
  }

  async getVotingSession(id: number): Promise<VotingSession | undefined> {
    const [session] = await db.select().from(votingSessions).where(eq(votingSessions.id, id));
    return session || undefined;
  }

  async updateVotingSession(id: number, updates: Partial<VotingSession>): Promise<VotingSession | undefined> {
    const [session] = await db
      .update(votingSessions)
      .set(updates)
      .where(eq(votingSessions.id, id))
      .returning();
    return session || undefined;
  }

  async createVote(vote: InsertVote): Promise<Vote> {
    const [newVote] = await db
      .insert(votes)
      .values(vote)
      .returning();
    return newVote;
  }

  async getVotes(sessionId: number): Promise<Vote[]> {
    return await db.select().from(votes).where(eq(votes.sessionId, sessionId));
  }

  async getVoteByDelegateAndSession(delegateId: number, sessionId: number): Promise<Vote | undefined> {
    const [vote] = await db.select().from(votes).where(and(eq(votes.delegateId, delegateId), eq(votes.sessionId, sessionId)));
    return vote || undefined;
  }

  async createAuditLog(log: InsertAuditLog): Promise<AuditLog> {
    const [newLog] = await db
      .insert(auditLogs)
      .values(log)
      .returning();
    return newLog;
  }

  async getAuditLogs(userId?: number, limit: number = 100): Promise<AuditLog[]> {
    const query = db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(limit);
    if (userId) {
      return await query.where(eq(auditLogs.userId, userId));
    }
    return await query;
  }

  async getVotingStats(sessionId: number): Promise<{ yes: number; no: number; abstain: number; total: number; }> {
    const allVotes = await this.getVotes(sessionId);
    const stats = {
      yes: allVotes.filter(v => v.voteType === 'yes').length,
      no: allVotes.filter(v => v.voteType === 'no').length,
      abstain: allVotes.filter(v => v.voteType === 'abstain').length,
      total: allVotes.length
    };
    return stats;
  }

  async getDelegateStats(delegateId: number): Promise<{ totalVotes: number; participationRate: number; }> {
    // Get all votes by this delegate
    const delegateVotes = await db.select().from(votes).where(eq(votes.delegateId, delegateId));
    
    // Get all sessions for this delegate's committee
    const delegate = await this.getDelegate(delegateId);
    if (!delegate) {
      return { totalVotes: 0, participationRate: 0 };
    }
    
    const allSessions = await this.getVotingSessions(delegate.committeeId);
    const completedSessions = allSessions.filter(s => s.status === 'completed');
    
    const participationRate = completedSessions.length > 0 ? (delegateVotes.length / completedSessions.length) * 100 : 0;
    
    return {
      totalVotes: delegateVotes.length,
      participationRate: Math.round(participationRate)
    };
  }
}

export const storage = new DatabaseStorage();
