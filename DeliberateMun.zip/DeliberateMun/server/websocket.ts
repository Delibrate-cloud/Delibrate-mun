import { WebSocketServer, WebSocket } from 'ws';
import type { Server } from 'http';
import { verifyToken } from './auth';
import { storage } from './storage';

interface AuthenticatedWebSocket extends WebSocket {
  userId?: number;
  role?: string;
  committeeId?: number;
}

interface WebSocketMessage {
  type: string;
  data: any;
}

export class WebSocketManager {
  private wss: WebSocketServer;
  private clients: Map<number, AuthenticatedWebSocket[]> = new Map();

  constructor(server: Server) {
    this.wss = new WebSocketServer({ server, path: '/ws' });
    this.setupWebSocket();
  }

  private setupWebSocket() {
    this.wss.on('connection', async (ws: AuthenticatedWebSocket, req) => {
      console.log('New WebSocket connection');

      // Handle authentication
      ws.on('message', async (data) => {
        try {
          const message: WebSocketMessage = JSON.parse(data.toString());
          
          if (message.type === 'auth') {
            const { token } = message.data;
            const payload = verifyToken(token);
            
            if (payload) {
              const user = await storage.getUser(payload.userId);
              if (user && user.isActive) {
                ws.userId = user.id;
                ws.role = user.role;
                
                // For delegates, get their committee
                if (user.role === 'delegate') {
                  const delegate = await storage.getDelegateByUserId(user.id);
                  if (delegate) {
                    ws.committeeId = delegate.committeeId;
                  }
                }
                
                // Add to clients map
                if (!this.clients.has(user.id)) {
                  this.clients.set(user.id, []);
                }
                this.clients.get(user.id)!.push(ws);
                
                ws.send(JSON.stringify({ type: 'auth_success', data: { role: user.role } }));
                console.log(`User ${user.username} authenticated via WebSocket`);
              }
            } else {
              ws.send(JSON.stringify({ type: 'auth_error', data: { message: 'Invalid token' } }));
              ws.close();
            }
          } else if (message.type === 'vote_cast') {
            // Handle real-time vote updates
            await this.handleVoteCast(ws, message.data);
          }
        } catch (error) {
          console.error('WebSocket message error:', error);
          ws.send(JSON.stringify({ type: 'error', data: { message: 'Invalid message format' } }));
        }
      });

      ws.on('close', () => {
        // Remove from clients map
        if (ws.userId) {
          const userConnections = this.clients.get(ws.userId);
          if (userConnections) {
            const index = userConnections.indexOf(ws);
            if (index > -1) {
              userConnections.splice(index, 1);
            }
            if (userConnections.length === 0) {
              this.clients.delete(ws.userId);
            }
          }
        }
        console.log('WebSocket connection closed');
      });

      ws.on('error', (error) => {
        console.error('WebSocket error:', error);
      });
    });
  }

  private async handleVoteCast(ws: AuthenticatedWebSocket, data: any) {
    if (ws.role !== 'delegate' || !ws.userId || !ws.committeeId) {
      return;
    }

    const { sessionId, voteType } = data;
    
    // Broadcast vote update to committee members and admins
    await this.broadcastToCommittee(ws.committeeId, {
      type: 'vote_update',
      data: {
        sessionId,
        voteType,
        delegateId: ws.userId,
        timestamp: new Date().toISOString()
      }
    });

    // Get updated voting stats
    const stats = await storage.getVotingStats(sessionId);
    await this.broadcastToCommittee(ws.committeeId, {
      type: 'voting_stats_update',
      data: { sessionId, stats }
    });
  }

  public async broadcastToCommittee(committeeId: number, message: WebSocketMessage) {
    // Get all delegates in committee
    const delegates = await storage.getDelegates(committeeId);
    const delegateUserIds = delegates.map(d => d.userId);

    // Get committee admin
    const committee = await storage.getCommittee(committeeId);
    const adminUserIds = committee?.adminId ? [committee.adminId] : [];

    // Broadcast to all relevant users
    const targetUserIds = [...delegateUserIds, ...adminUserIds];
    
    for (const userId of targetUserIds) {
      const connections = this.clients.get(userId);
      if (connections) {
        connections.forEach(ws => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify(message));
          }
        });
      }
    }
  }

  public async broadcastVotingSessionUpdate(committeeId: number, sessionData: any) {
    await this.broadcastToCommittee(committeeId, {
      type: 'voting_session_update',
      data: sessionData
    });
  }

  public async notifyAdmins(message: WebSocketMessage) {
    // Get all admin users
    for (const [userId, connections] of this.clients.entries()) {
      const user = await storage.getUser(userId);
      if (user && (user.role === 'admin' || user.role === 'founder')) {
        connections.forEach(ws => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify(message));
          }
        });
      }
    }
  }
}

let wsManager: WebSocketManager;

export function initializeWebSocket(server: Server): WebSocketManager {
  wsManager = new WebSocketManager(server);
  return wsManager;
}

export function getWebSocketManager(): WebSocketManager {
  return wsManager;
}
