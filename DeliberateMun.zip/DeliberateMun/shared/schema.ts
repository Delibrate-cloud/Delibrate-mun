import { pgTable, text, serial, integer, boolean, timestamp, json, varchar } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 255 }).notNull().unique(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  password: text("password").notNull(),
  role: varchar("role", { length: 50 }).notNull(), // 'founder', 'admin', 'delegate'
  fullName: text("full_name"),
  isActive: boolean("is_active").default(true),
  lastLogin: timestamp("last_login"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const adminRequests = pgTable("admin_requests", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  munExperience: text("mun_experience").notNull(),
  reasonForAccess: text("reason_for_access").notNull(),
  previousAdminExperience: text("previous_admin_experience"),
  acceptedPolicies: boolean("accepted_policies").notNull(),
  status: varchar("status", { length: 50 }).default("pending"), // 'pending', 'approved', 'rejected'
  reviewedBy: integer("reviewed_by"),
  reviewFeedback: text("review_feedback"),
  createdAt: timestamp("created_at").defaultNow(),
  reviewedAt: timestamp("reviewed_at"),
});

export const committees = pgTable("committees", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  abbreviation: varchar("abbreviation", { length: 10 }).notNull(),
  description: text("description"),
  adminId: integer("admin_id"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const delegates = pgTable("delegates", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  committeeId: integer("committee_id").notNull(),
  country: varchar("country", { length: 255 }).notNull(),
  position: varchar("position", { length: 255 }),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const votingSessions = pgTable("voting_sessions", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  committeeId: integer("committee_id").notNull(),
  adminId: integer("admin_id").notNull(),
  votingType: varchar("voting_type", { length: 50 }).notNull(), // 'simple', 'two_thirds', 'consensus'
  status: varchar("status", { length: 50 }).default("active"), // 'active', 'completed', 'cancelled'
  duration: integer("duration").default(5), // duration in minutes
  startTime: timestamp("start_time").defaultNow(),
  endTime: timestamp("end_time"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const votes = pgTable("votes", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull(),
  delegateId: integer("delegate_id").notNull(),
  voteType: varchar("vote_type", { length: 20 }).notNull(), // 'yes', 'no', 'abstain'
  castAt: timestamp("cast_at").defaultNow(),
});

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  action: varchar("action", { length: 255 }).notNull(),
  entityType: varchar("entity_type", { length: 100 }),
  entityId: integer("entity_id"),
  details: json("details"),
  ipAddress: varchar("ip_address", { length: 45 }),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  adminRequests: many(adminRequests),
  committees: many(committees),
  delegates: many(delegates),
  votingSessions: many(votingSessions),
  auditLogs: many(auditLogs),
}));

export const adminRequestsRelations = relations(adminRequests, ({ one }) => ({
  reviewer: one(users, { fields: [adminRequests.reviewedBy], references: [users.id] }),
}));

export const committeesRelations = relations(committees, ({ one, many }) => ({
  admin: one(users, { fields: [committees.adminId], references: [users.id] }),
  delegates: many(delegates),
  votingSessions: many(votingSessions),
}));

export const delegatesRelations = relations(delegates, ({ one, many }) => ({
  user: one(users, { fields: [delegates.userId], references: [users.id] }),
  committee: one(committees, { fields: [delegates.committeeId], references: [committees.id] }),
  votes: many(votes),
}));

export const votingSessionsRelations = relations(votingSessions, ({ one, many }) => ({
  committee: one(committees, { fields: [votingSessions.committeeId], references: [committees.id] }),
  admin: one(users, { fields: [votingSessions.adminId], references: [users.id] }),
  votes: many(votes),
}));

export const votesRelations = relations(votes, ({ one }) => ({
  session: one(votingSessions, { fields: [votes.sessionId], references: [votingSessions.id] }),
  delegate: one(delegates, { fields: [votes.delegateId], references: [delegates.id] }),
}));

export const auditLogsRelations = relations(auditLogs, ({ one }) => ({
  user: one(users, { fields: [auditLogs.userId], references: [users.id] }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  lastLogin: true,
});

export const insertAdminRequestSchema = createInsertSchema(adminRequests).omit({
  id: true,
  createdAt: true,
  reviewedAt: true,
  reviewedBy: true,
  reviewFeedback: true,
  status: true,
});

export const insertCommitteeSchema = createInsertSchema(committees).omit({
  id: true,
  createdAt: true,
});

export const insertDelegateSchema = createInsertSchema(delegates).omit({
  id: true,
  createdAt: true,
});

export const insertVotingSessionSchema = createInsertSchema(votingSessions).omit({
  id: true,
  createdAt: true,
  startTime: true,
  endTime: true,
});

export const insertVoteSchema = createInsertSchema(votes).omit({
  id: true,
  castAt: true,
});

export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type AdminRequest = typeof adminRequests.$inferSelect;
export type InsertAdminRequest = z.infer<typeof insertAdminRequestSchema>;
export type Committee = typeof committees.$inferSelect;
export type InsertCommittee = z.infer<typeof insertCommitteeSchema>;
export type Delegate = typeof delegates.$inferSelect;
export type InsertDelegate = z.infer<typeof insertDelegateSchema>;
export type VotingSession = typeof votingSessions.$inferSelect;
export type InsertVotingSession = z.infer<typeof insertVotingSessionSchema>;
export type Vote = typeof votes.$inferSelect;
export type InsertVote = z.infer<typeof insertVoteSchema>;
export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
