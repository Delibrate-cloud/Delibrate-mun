import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { X, Volume2, VolumeX } from "lucide-react";

interface VideoAdModalProps {
  isOpen: boolean;
  onClose: () => void;
  videoUrl: string;
}

export default function VideoAdModal({ isOpen, onClose, videoUrl }: VideoAdModalProps) {
  const [isMuted, setIsMuted] = useState(false);
  const [canClose, setCanClose] = useState(false);
  const [timeLeft, setTimeLeft] = useState(5); // 5 seconds before close button appears

  useEffect(() => {
    if (isOpen) {
      setCanClose(false);
      setTimeLeft(5);
      
      const timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            setCanClose(true);
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [isOpen]);

  const handleClose = () => {
    if (canClose) {
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-4xl p-0 bg-black border-none">
        <div className="relative">
          {/* Close Button */}
          <div className="absolute top-4 right-4 z-10">
            {canClose ? (
              <Button
                variant="destructive"
                size="sm"
                onClick={handleClose}
                className="bg-red-600 hover:bg-red-700 rounded-full w-10 h-10 p-0"
              >
                <X className="h-5 w-5" />
              </Button>
            ) : (
              <div className="bg-red-600 text-white rounded-full w-10 h-10 flex items-center justify-center text-sm font-bold">
                {timeLeft}
              </div>
            )}
          </div>

          {/* Mute/Unmute Button */}
          <div className="absolute top-4 left-4 z-10">
            <Button
              variant="secondary"
              size="sm"
              onClick={() => setIsMuted(!isMuted)}
              className="bg-black/50 hover:bg-black/70 rounded-full w-10 h-10 p-0"
            >
              {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
            </Button>
          </div>

          {/* Video Container */}
          <div className="aspect-video bg-black rounded-lg overflow-hidden">
            <video
              className="w-full h-full object-cover"
              autoPlay
              muted={isMuted}
              controls={false}
              playsInline
            >
              <source src={videoUrl} type="video/mp4" />
              <div className="flex items-center justify-center h-full text-white">
                <div className="text-center">
                  <h3 className="text-xl font-bold mb-2">Video Ad</h3>
                  <p className="text-gray-300">Loading advertisement...</p>
                </div>
              </div>
            </video>
          </div>

          {/* Ad Info Bar */}
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
            <div className="flex justify-between items-center text-white">
              <div>
                <p className="text-sm font-medium">Advertisement</p>
                <p className="text-xs text-gray-300">Support Deliberate.in</p>
              </div>
              {!canClose && (
                <div className="text-sm">
                  Close in {timeLeft}s
                </div>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}