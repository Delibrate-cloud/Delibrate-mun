import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { X } from "lucide-react";

interface CreateVotingModalProps {
  isOpen: boolean;
  onClose: () => void;
  committeeId: number | null;
}

export default function CreateVotingModal({ 
  isOpen, 
  onClose, 
  committeeId 
}: CreateVotingModalProps) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    votingType: "simple",
    duration: 5,
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest('POST', '/api/voting-sessions', {
        ...data,
        committeeId,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/voting-sessions'] });
      toast({
        title: "Voting Session Created",
        description: "The voting session has been started successfully",
      });
      onClose();
      setFormData({
        title: "",
        description: "",
        votingType: "simple",
        duration: 5,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Creation Failed",
        description: error.message || "Failed to create voting session",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title || !formData.description) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    if (!committeeId) {
      toast({
        title: "Error",
        description: "No committee selected",
        variant: "destructive",
      });
      return;
    }

    createMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleClose = () => {
    setFormData({
      title: "",
      description: "",
      votingType: "simple",
      duration: 5,
    });
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>Create New Voting Session</DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleClose}
              className="h-6 w-6"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Resolution Title *</Label>
            <Input
              id="title"
              type="text"
              placeholder="Enter resolution title"
              value={formData.title}
              onChange={(e) => handleInputChange('title', e.target.value)}
              disabled={createMutation.isPending}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              placeholder="Brief description of the resolution"
              rows={3}
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              disabled={createMutation.isPending}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="votingType">Voting Type</Label>
              <Select
                value={formData.votingType}
                onValueChange={(value) => handleInputChange('votingType', value)}
                disabled={createMutation.isPending}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select voting type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="simple">Simple Majority</SelectItem>
                  <SelectItem value="two_thirds">Two-thirds Majority</SelectItem>
                  <SelectItem value="consensus">Consensus</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="duration">Duration (minutes)</Label>
              <Input
                id="duration"
                type="number"
                min="1"
                max="60"
                value={formData.duration}
                onChange={(e) => handleInputChange('duration', parseInt(e.target.value) || 5)}
                disabled={createMutation.isPending}
              />
            </div>
          </div>
          
          <div className="flex space-x-3 pt-4">
            <Button
              type="button"
              onClick={handleClose}
              variant="outline"
              className="flex-1"
              disabled={createMutation.isPending}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-green-600 hover:bg-green-700"
              disabled={createMutation.isPending}
            >
              {createMutation.isPending ? "Creating..." : "Start Voting"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
