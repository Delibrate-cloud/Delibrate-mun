import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Check, X, Minus, Clock } from "lucide-react";

interface VotingModalProps {
  isOpen: boolean;
  onClose: () => void;
  session: any;
  onVote: (sessionId: number, voteType: string) => void;
  isLoading: boolean;
}

export default function VotingModal({ 
  isOpen, 
  onClose, 
  session, 
  onVote, 
  isLoading 
}: VotingModalProps) {
  const [selectedVote, setSelectedVote] = useState<string | null>(null);

  if (!session) return null;

  const handleVoteSelect = (voteType: string) => {
    setSelectedVote(voteType);
  };

  const handleConfirmVote = () => {
    if (!selectedVote) return;
    onVote(session.id, selectedVote);
    setSelectedVote(null);
  };

  const handleClose = () => {
    setSelectedVote(null);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <div className="text-center mb-6">
            <DialogTitle className="text-xl font-semibold mb-2">
              Cast Your Vote
            </DialogTitle>
            <p className="text-muted-foreground">{session.title}</p>
            <p className="text-sm text-muted-foreground">
              {session.description}
            </p>
          </div>
        </DialogHeader>

        <Card className="mb-6">
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground leading-relaxed">
              {session.description || "Please review the resolution or motion carefully before casting your vote. Your decision will be recorded and cannot be changed once submitted."}
            </p>
          </CardContent>
        </Card>

        <div className="grid grid-cols-3 gap-3 mb-6">
          <Button
            onClick={() => handleVoteSelect('yes')}
            variant={selectedVote === 'yes' ? 'default' : 'outline'}
            className={`vote-option py-8 px-6 flex flex-col items-center space-y-2 transition-all duration-200 transform hover:scale-105 ${
              selectedVote === 'yes' 
                ? 'bg-green-600 hover:bg-green-700 text-white border-green-600' 
                : 'border-green-600 text-green-600 hover:bg-green-600/10'
            }`}
          >
            <Check className="h-6 w-6" />
            <span className="font-semibold">YES</span>
            <span className="text-xs opacity-75">In Favor</span>
          </Button>
          
          <Button
            onClick={() => handleVoteSelect('no')}
            variant={selectedVote === 'no' ? 'default' : 'outline'}
            className={`vote-option py-8 px-6 flex flex-col items-center space-y-2 transition-all duration-200 transform hover:scale-105 ${
              selectedVote === 'no' 
                ? 'bg-red-600 hover:bg-red-700 text-white border-red-600' 
                : 'border-red-600 text-red-600 hover:bg-red-600/10'
            }`}
          >
            <X className="h-6 w-6" />
            <span className="font-semibold">NO</span>
            <span className="text-xs opacity-75">Against</span>
          </Button>
          
          <Button
            onClick={() => handleVoteSelect('abstain')}
            variant={selectedVote === 'abstain' ? 'default' : 'outline'}
            className={`vote-option py-8 px-6 flex flex-col items-center space-y-2 transition-all duration-200 transform hover:scale-105 ${
              selectedVote === 'abstain' 
                ? 'bg-yellow-600 hover:bg-yellow-700 text-white border-yellow-600' 
                : 'border-yellow-600 text-yellow-600 hover:bg-yellow-600/10'
            }`}
          >
            <Minus className="h-6 w-6" />
            <span className="font-semibold">ABSTAIN</span>
            <span className="text-xs opacity-75">No Position</span>
          </Button>
        </div>

        <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
          <div className="flex items-center space-x-1">
            <Clock className="h-4 w-4" />
            <span>Time remaining:</span>
          </div>
          <span className="font-semibold text-amber-500">
            {session.duration || 5} minutes
          </span>
        </div>

        <div className="flex space-x-3">
          <Button
            onClick={handleClose}
            variant="outline"
            className="flex-1"
            disabled={isLoading}
          >
            Cancel
          </Button>
          <Button
            onClick={handleConfirmVote}
            className="flex-1 bg-primary hover:bg-primary/90"
            disabled={!selectedVote || isLoading}
          >
            {isLoading ? "Casting Vote..." : "Confirm Vote"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
