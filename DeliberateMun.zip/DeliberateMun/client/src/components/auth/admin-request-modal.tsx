import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { X } from "lucide-react";

interface AdminRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AdminRequestModal({ isOpen, onClose }: AdminRequestModalProps) {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    munExperience: "",
    reasonForAccess: "",
    previousAdminExperience: "",
    acceptedPolicies: false,
  });
  const { toast } = useToast();

  const submitMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest('POST', '/api/admin-requests', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Request Submitted",
        description: "Your admin request has been submitted for review",
      });
      onClose();
      setFormData({
        fullName: "",
        email: "",
        munExperience: "",
        reasonForAccess: "",
        previousAdminExperience: "",
        acceptedPolicies: false,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Submission Failed",
        description: error.message || "Failed to submit admin request",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.fullName || !formData.email || !formData.munExperience || 
        !formData.reasonForAccess || !formData.acceptedPolicies) {
      toast({
        title: "Error",
        description: "Please fill in all required fields and accept the policies",
        variant: "destructive",
      });
      return;
    }

    submitMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>Request Admin Access</DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="h-6 w-6"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="fullName">Full Name *</Label>
            <Input
              id="fullName"
              type="text"
              placeholder="Enter your full name"
              value={formData.fullName}
              onChange={(e) => handleInputChange('fullName', e.target.value)}
              disabled={submitMutation.isPending}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="email">Email Address *</Label>
            <Input
              id="email"
              type="email"
              placeholder="Enter your email"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              disabled={submitMutation.isPending}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="munExperience">MUN Experience *</Label>
            <Textarea
              id="munExperience"
              placeholder="Describe your MUN experience and background"
              rows={3}
              value={formData.munExperience}
              onChange={(e) => handleInputChange('munExperience', e.target.value)}
              disabled={submitMutation.isPending}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="reasonForAccess">Reason for Admin Access *</Label>
            <Textarea
              id="reasonForAccess"
              placeholder="Explain why you need admin access to this platform"
              rows={3}
              value={formData.reasonForAccess}
              onChange={(e) => handleInputChange('reasonForAccess', e.target.value)}
              disabled={submitMutation.isPending}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="previousAdminExperience">Previous Admin Experience</Label>
            <Textarea
              id="previousAdminExperience"
              placeholder="Describe any previous admin experience (optional)"
              rows={2}
              value={formData.previousAdminExperience}
              onChange={(e) => handleInputChange('previousAdminExperience', e.target.value)}
              disabled={submitMutation.isPending}
            />
          </div>
          
          <div className="flex items-start space-x-2">
            <Checkbox
              id="policies"
              checked={formData.acceptedPolicies}
              onCheckedChange={(checked) => handleInputChange('acceptedPolicies', checked as boolean)}
              disabled={submitMutation.isPending}
            />
            <Label htmlFor="policies" className="text-sm leading-5">
              I accept the platform policies and understand my responsibilities as an admin *
            </Label>
          </div>
          
          <Button
            type="submit"
            className="w-full bg-primary hover:bg-primary/90 font-semibold"
            disabled={submitMutation.isPending}
          >
            {submitMutation.isPending ? "Submitting..." : "Submit Admin Request"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
