import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { X } from "lucide-react";

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  type: 'founder' | 'admin' | 'delegate';
}

export default function LoginModal({ isOpen, onClose, title, type }: LoginModalProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const { login, isLoading } = useAuth();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!username || !password) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    try {
      await login(username, password);
      onClose();
      setUsername("");
      setPassword("");
      
      toast({
        title: "Success",
        description: "Login successful",
      });
    } catch (error: any) {
      toast({
        title: "Login Failed",
        description: error.message || "Invalid credentials",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>{title}</DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="h-6 w-6"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="username">Username</Label>
            <Input
              id="username"
              type="text"
              placeholder={`Enter ${type === 'founder' ? 'founder' : type === 'admin' ? 'admin' : 'your'} username`}
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              disabled={isLoading}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              placeholder={`Enter ${type === 'founder' ? 'founder' : type === 'admin' ? 'admin' : 'your'} password`}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={isLoading}
            />
          </div>
          
          <Button
            type="submit"
            className={`w-full font-semibold ${
              type === 'founder' 
                ? 'bg-amber-600 hover:bg-amber-700 text-black' 
                : type === 'admin'
                ? 'bg-blue-600 hover:bg-blue-700 text-white'
                : 'bg-primary hover:bg-primary/90'
            }`}
            disabled={isLoading}
          >
            {isLoading ? "Signing in..." : `Access ${type === 'founder' ? 'Founder' : type === 'admin' ? 'Admin' : 'Delegate'} Panel`}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
