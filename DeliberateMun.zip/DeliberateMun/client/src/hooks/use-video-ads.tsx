import { useState, useEffect, useRef } from "react";

interface VideoAdConfig {
  enabled: boolean;
  intervalMinutes: number; // Default 20 minutes
  videoUrl: string;
}

export function useVideoAds(config: VideoAdConfig) {
  const [showAd, setShowAd] = useState(false);
  const [lastAdTime, setLastAdTime] = useState<number>(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (!config.enabled) return;

    const startAdTimer = () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }

      timerRef.current = setInterval(() => {
        const now = Date.now();
        const timeSinceLastAd = now - lastAdTime;
        const intervalMs = config.intervalMinutes * 60 * 1000;

        if (timeSinceLastAd >= intervalMs) {
          setShowAd(true);
          setLastAdTime(now);
        }
      }, 60000); // Check every minute
    };

    // Start timer on mount
    startAdTimer();
    setLastAdTime(Date.now());

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [config.enabled, config.intervalMinutes, lastAdTime]);

  const closeAd = () => {
    setShowAd(false);
    setLastAdTime(Date.now());
  };

  const getNextAdTime = () => {
    const intervalMs = config.intervalMinutes * 60 * 1000;
    return new Date(lastAdTime + intervalMs);
  };

  const getTimeUntilNextAd = () => {
    const now = Date.now();
    const nextAdTime = getNextAdTime().getTime();
    const timeLeft = Math.max(0, nextAdTime - now);
    
    const minutes = Math.floor(timeLeft / (1000 * 60));
    const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);
    
    return { minutes, seconds, totalMs: timeLeft };
  };

  return {
    showAd,
    closeAd,
    getNextAdTime,
    getTimeUntilNextAd,
    videoUrl: config.videoUrl
  };
}