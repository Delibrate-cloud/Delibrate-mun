import { createContext, useContext, useEffect, useRef, ReactNode } from "react";
import { useAuth } from "./use-auth";
import { useToast } from "./use-toast";

interface WebSocketMessage {
  type: string;
  data: any;
}

interface WebSocketContextType {
  sendMessage: (message: WebSocketMessage) => void;
  isConnected: boolean;
}

const WebSocketContext = createContext<WebSocketContextType | undefined>(undefined);

export function WebSocketProvider({ children }: { children: ReactNode }) {
  const { token, user } = useAuth();
  const { toast } = useToast();
  const ws = useRef<WebSocket | null>(null);
  const isConnected = useRef(false);

  useEffect(() => {
    if (!token || !user) {
      if (ws.current) {
        ws.current.close();
        ws.current = null;
        isConnected.current = false;
      }
      return;
    }

    // Create WebSocket connection
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    ws.current = new WebSocket(wsUrl);

    ws.current.onopen = () => {
      console.log('WebSocket connected');
      isConnected.current = true;
      
      // Authenticate
      ws.current?.send(JSON.stringify({
        type: 'auth',
        data: { token }
      }));
    };

    ws.current.onmessage = (event) => {
      try {
        const message: WebSocketMessage = JSON.parse(event.data);
        handleWebSocketMessage(message);
      } catch (error) {
        console.error('Failed to parse WebSocket message:', error);
      }
    };

    ws.current.onclose = () => {
      console.log('WebSocket disconnected');
      isConnected.current = false;
    };

    ws.current.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    return () => {
      if (ws.current) {
        ws.current.close();
        ws.current = null;
        isConnected.current = false;
      }
    };
  }, [token, user]);

  const handleWebSocketMessage = (message: WebSocketMessage) => {
    switch (message.type) {
      case 'auth_success':
        console.log('WebSocket authenticated successfully');
        break;
        
      case 'auth_error':
        console.error('WebSocket authentication failed:', message.data.message);
        break;
        
      case 'new_admin_request':
        if (user?.role === 'founder') {
          toast({
            title: "New Admin Request",
            description: `New admin request from ${message.data.email}`,
          });
        }
        break;
        
      case 'voting_session_update':
        if (message.data.status === 'started') {
          toast({
            title: "Voting Session Started",
            description: `New voting session: ${message.data.title}`,
          });
        } else if (message.data.status === 'completed') {
          toast({
            title: "Voting Session Ended",
            description: `Voting session completed: ${message.data.title}`,
          });
        }
        break;
        
      case 'vote_update':
        // Real-time vote updates for admins
        if (user?.role === 'admin' || user?.role === 'founder') {
          // Update UI with new vote data
          console.log('Vote update received:', message.data);
        }
        break;
        
      case 'voting_stats_update':
        // Update voting statistics in real-time
        console.log('Voting stats update:', message.data);
        break;
        
      default:
        console.log('Unknown WebSocket message type:', message.type);
    }
  };

  const sendMessage = (message: WebSocketMessage) => {
    if (ws.current && isConnected.current) {
      ws.current.send(JSON.stringify(message));
    } else {
      console.warn('WebSocket not connected, cannot send message');
    }
  };

  return (
    <WebSocketContext.Provider
      value={{
        sendMessage,
        isConnected: isConnected.current,
      }}
    >
      {children}
    </WebSocketContext.Provider>
  );
}

export function useWebSocket() {
  const context = useContext(WebSocketContext);
  if (context === undefined) {
    throw new Error('useWebSocket must be used within a WebSocketProvider');
  }
  return context;
}
