import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { requireAuth } from "@/lib/auth";
import CreateVotingModal from "@/components/voting/create-voting-modal";
import { 
  Users, 
  Vote, 
  CheckCircle, 
  TrendingUp,
  Plus,
  Edit,
  Play,
  Square,
  Clock
} from "lucide-react";

export default function AdminDashboard() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showCreateVoting, setShowCreateVoting] = useState(false);
  const [selectedCommittee, setSelectedCommittee] = useState<number | null>(null);

  useEffect(() => {
    if (user && !requireAuth(user.role, ['admin'])) {
      setLocation('/');
    }
  }, [user, setLocation]);

  const { data: committees = [] } = useQuery({
    queryKey: ['/api/committees'],
    enabled: !!user && user.role === 'admin',
  });

  const { data: delegates = [] } = useQuery({
    queryKey: ['/api/delegates', selectedCommittee],
    enabled: !!user && user.role === 'admin' && !!selectedCommittee,
  });

  const { data: votingSessions = [] } = useQuery({
    queryKey: ['/api/voting-sessions', selectedCommittee],
    enabled: !!user && user.role === 'admin' && !!selectedCommittee,
  });

  const endVotingMutation = useMutation({
    mutationFn: async (sessionId: number) => {
      const response = await apiRequest('PATCH', `/api/voting-sessions/${sessionId}`, {
        status: 'completed'
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/voting-sessions'] });
      toast({
        title: "Voting Ended",
        description: "Voting session has been completed",
      });
    },
  });

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Access Denied</h1>
          <p className="text-muted-foreground mb-4">You don't have permission to access this page.</p>
          <Button onClick={() => setLocation('/')}>Go Home</Button>
        </div>
      </div>
    );
  }

  const activeCommittee = committees.find((c: any) => c.id === selectedCommittee);
  const activeSessions = votingSessions.filter((s: any) => s.status === 'active');
  const completedSessions = votingSessions.filter((s: any) => s.status === 'completed');

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <nav className="bg-card border-b border-border px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-xl font-bold">Deliberate.in</h1>
            <span className="text-sm text-muted-foreground">Admin Dashboard</span>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Committee Tabs */}
            {committees.length > 0 && (
              <div className="flex bg-muted rounded-lg p-1 space-x-1">
                {committees.slice(0, 4).map((committee: any) => (
                  <Button
                    key={committee.id}
                    variant={selectedCommittee === committee.id ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setSelectedCommittee(committee.id)}
                    className="text-sm"
                  >
                    {committee.abbreviation}
                  </Button>
                ))}
                {committees.length > 4 && (
                  <Button variant="ghost" size="sm" className="text-sm">
                    +
                  </Button>
                )}
              </div>
            )}
            
            <div className="text-right">
              <p className="text-sm font-medium">Admin Portal</p>
              <p className="text-xs text-muted-foreground">Multi-Committee View</p>
            </div>
            <Button variant="outline" size="sm" onClick={logout}>
              Logout
            </Button>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-6">
        {committees.length === 0 ? (
          <div className="text-center py-16">
            <h2 className="text-2xl font-bold mb-4">No Committees Assigned</h2>
            <p className="text-muted-foreground">
              Please contact the founder to get committee assignments.
            </p>
          </div>
        ) : !selectedCommittee ? (
          <div className="text-center py-16">
            <h2 className="text-2xl font-bold mb-4">Select a Committee</h2>
            <p className="text-muted-foreground mb-6">
              Choose a committee from the tabs above to manage delegates and voting sessions.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-4xl mx-auto">
              {committees.map((committee: any) => (
                <Card
                  key={committee.id}
                  className="cursor-pointer hover:bg-muted/50 transition-colors"
                  onClick={() => setSelectedCommittee(committee.id)}
                >
                  <CardContent className="p-6 text-center">
                    <h3 className="font-semibold text-lg mb-2">{committee.name}</h3>
                    <p className="text-sm text-muted-foreground">{committee.abbreviation}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        ) : (
          <>
            {/* Committee Stats */}
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-bold">{activeCommittee?.name}</h2>
                <p className="text-muted-foreground">Committee Management</p>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Delegates</p>
                      <p className="text-2xl font-bold text-primary">{delegates.length}</p>
                    </div>
                    <Users className="h-5 w-5 text-primary" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Active Votes</p>
                      <p className="text-2xl font-bold text-amber-500">{activeSessions.length}</p>
                    </div>
                    <Vote className="h-5 w-5 text-amber-500" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Completed</p>
                      <p className="text-2xl font-bold text-green-500">{completedSessions.length}</p>
                    </div>
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Participation</p>
                      <p className="text-2xl font-bold text-green-500">94%</p>
                    </div>
                    <TrendingUp className="h-5 w-5 text-green-500" />
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid lg:grid-cols-2 gap-6">
              {/* Delegate Management */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Committee Delegates</CardTitle>
                    <Button size="sm" className="bg-primary hover:bg-primary/90">
                      <Plus className="w-4 h-4 mr-1" />
                      Add Delegate
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {delegates.length === 0 ? (
                    <p className="text-muted-foreground text-center py-8">No delegates assigned</p>
                  ) : (
                    <div className="space-y-3">
                      {delegates.map((delegate: any) => (
                        <div
                          key={delegate.id}
                          className="flex items-center justify-between bg-muted/50 rounded-lg p-3"
                        >
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-sm font-semibold text-primary-foreground">
                              {delegate.country?.slice(0, 2).toUpperCase()}
                            </div>
                            <div>
                              <p className="font-medium">{delegate.country}</p>
                              <p className="text-sm text-muted-foreground">
                                {delegate.user?.email}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <span className="status-indicator status-online"></span>
                            <Button variant="ghost" size="icon">
                              <Edit className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Active Voting Sessions */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Voting Sessions</CardTitle>
                    <Button
                      size="sm"
                      className="bg-green-600 hover:bg-green-700"
                      onClick={() => setShowCreateVoting(true)}
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      New Vote
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {activeSessions.map((session: any) => (
                      <Card key={session.id} className="border-amber-500/30">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-semibold">{session.title}</h4>
                            <Badge className="bg-amber-500/20 text-amber-500">
                              VOTING
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-3">
                            {session.description}
                          </p>
                          <div className="flex items-center justify-between">
                            <div className="text-sm">
                              <Clock className="w-4 h-4 inline mr-1" />
                              {session.duration} minutes
                            </div>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => endVotingMutation.mutate(session.id)}
                              disabled={endVotingMutation.isPending}
                            >
                              <Square className="w-4 h-4 mr-1" />
                              End Vote
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                    
                    {completedSessions.slice(0, 2).map((session: any) => (
                      <Card key={session.id} className="border-green-500/30">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-semibold">{session.title}</h4>
                            <Badge className="bg-green-500/20 text-green-500">
                              COMPLETED
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {session.description}
                          </p>
                        </CardContent>
                      </Card>
                    ))}
                    
                    {activeSessions.length === 0 && completedSessions.length === 0 && (
                      <p className="text-muted-foreground text-center py-8">
                        No voting sessions yet
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </>
        )}
      </div>

      <CreateVotingModal
        isOpen={showCreateVoting}
        onClose={() => setShowCreateVoting(false)}
        committeeId={selectedCommittee}
      />
    </div>
  );
}
