import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import LoginModal from "@/components/auth/login-modal";
import AdminRequestModal from "@/components/auth/admin-request-modal";
import { Users, Lock, TrendingUp, Crown, Shield, User, Phone, Mail, Globe, Smartphone, Monitor, Tablet, UserPlus } from "lucide-react";

export default function Landing() {
  const [activeModal, setActiveModal] = useState<'founder' | 'admin' | 'delegate' | 'admin-request' | null>(null);

  return (
    <div className="min-h-screen gradient-bg">
      {/* Hero Section */}
      <div className="container mx-auto px-4 py-8 md:py-16">
        <div className="text-center py-8 md:py-16">
          <div className="mb-6">
            <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-amber-500 to-amber-600 rounded-2xl flex items-center justify-center">
              <Globe className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-amber-400 to-amber-600 bg-clip-text text-transparent">
              Deliberate.in
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-2 font-medium">
              Where Decisions Get Dignity
            </p>
            <p className="text-sm text-amber-400/80 mb-8">
              Powered by Shaurya Ghulati
            </p>
          </div>
          
          <div className="max-w-3xl mx-auto text-center mb-12">
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed mb-6">
              🚀 Smart, Secure, and Speedy MUN Voting Platform
            </p>
            <p className="text-base text-muted-foreground leading-relaxed">
              Transform your Model United Nations conferences with our digital voting platform 
              designed for transparency, efficiency, and seamless multi-device experience.
            </p>
          </div>

          {/* Platform Support */}
          <div className="flex justify-center items-center space-x-6 mb-12">
            <div className="flex flex-col items-center">
              <Monitor className="w-8 h-8 text-primary mb-2" />
              <span className="text-xs text-muted-foreground">PC/Laptop</span>
            </div>
            <div className="flex flex-col items-center">
              <Tablet className="w-8 h-8 text-primary mb-2" />
              <span className="text-xs text-muted-foreground">Tablet</span>
            </div>
            <div className="flex flex-col items-center">
              <Smartphone className="w-8 h-8 text-primary mb-2" />
              <span className="text-xs text-muted-foreground">Mobile</span>
            </div>
          </div>
        </div>

        {/* Feature Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Card className="card-hover bg-card/50 backdrop-blur border-border">
            <CardContent className="p-6">
              <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mb-4">
                <Users className="text-primary-foreground text-xl" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Role-Based Access</h3>
              <p className="text-muted-foreground text-sm">
                Secure three-tier system with Founder, Admin, and Delegate roles
              </p>
            </CardContent>
          </Card>
          
          <Card className="card-hover bg-card/50 backdrop-blur border-border">
            <CardContent className="p-6">
              <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mb-4">
                <Lock className="text-primary-foreground text-xl" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Secure Voting</h3>
              <p className="text-muted-foreground text-sm">
                Anonymous voting with comprehensive audit trails and security
              </p>
            </CardContent>
          </Card>
          
          <Card className="card-hover bg-card/50 backdrop-blur border-border">
            <CardContent className="p-6">
              <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mb-4">
                <TrendingUp className="text-primary-foreground text-xl" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Real-time Results</h3>
              <p className="text-muted-foreground text-sm">
                Live monitoring and instant result tabulation
              </p>
            </CardContent>
          </Card>
        </div>



        {/* Access Buttons */}
        <div className="max-w-md mx-auto space-y-4 mb-16">
          <Button
            onClick={() => setActiveModal('founder')}
            className="w-full bg-amber-600 hover:bg-amber-700 text-black font-semibold py-4 px-6 text-base h-auto transform transition-all hover:scale-105 shadow-lg"
          >
            <Crown className="mr-2 h-5 w-5" />
            Founder Access
          </Button>
          
          <Button
            onClick={() => setActiveModal('admin')}
            className="w-full bg-blue-600 hover:bg-blue-700 font-semibold py-4 px-6 text-base h-auto transform transition-all hover:scale-105 shadow-lg"
          >
            <Shield className="mr-2 h-5 w-5" />
            Admin Login
          </Button>
          
          <Button
            onClick={() => setActiveModal('admin-request')}
            className="w-full bg-primary hover:bg-primary/90 font-semibold py-4 px-6 text-base h-auto transform transition-all hover:scale-105 shadow-lg"
          >
            <UserPlus className="mr-2 h-5 w-5" />
            Request Admin Access
          </Button>
          
          <Button
            onClick={() => setActiveModal('delegate')}
            variant="secondary"
            className="w-full font-semibold py-4 px-6 text-base h-auto transform transition-all hover:scale-105 shadow-lg"
          >
            <User className="mr-2 h-5 w-5" />
            Delegate Login
          </Button>
        </div>

        {/* Contact & Support Section */}
        <div className="bg-card/30 backdrop-blur rounded-xl p-6 md:p-8 border border-border/50">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold mb-2">Help & Support</h3>
            <p className="text-muted-foreground">
              Need assistance or have questions? Get in touch with our founder.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6 max-w-2xl mx-auto">
            <Card className="card-hover bg-card/50 backdrop-blur border-border/50">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mb-4 mx-auto">
                  <Phone className="text-white text-xl" />
                </div>
                <h4 className="text-lg font-semibold mb-2">Call Us</h4>
                <p className="text-muted-foreground text-sm mb-3">
                  Direct line to founder
                </p>
                <a
                  href="tel:+919510799070"
                  className="text-green-400 hover:text-green-300 font-medium text-lg"
                >
                  +91 95107 99070
                </a>
              </CardContent>
            </Card>

            <Card className="card-hover bg-card/50 backdrop-blur border-border/50">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center mb-4 mx-auto">
                  <Mail className="text-white text-xl" />
                </div>
                <h4 className="text-lg font-semibold mb-2">Email Us</h4>
                <p className="text-muted-foreground text-sm mb-3">
                  Send us a message
                </p>
                <a
                  href="mailto:thecreeper8383@gmail.com"
                  className="text-blue-400 hover:text-blue-300 font-medium break-all"
                >
                  thecreeper8383@gmail.com
                </a>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-8 pt-6 border-t border-border/50">
            <p className="text-sm text-muted-foreground">
              Platform exclusively designed for Model United Nations conferences in India
            </p>
            <p className="text-xs text-muted-foreground mt-2">
              © 2024 Deliberate.in - All rights reserved | Founder: Shaurya Ghulati
            </p>
          </div>
        </div>
      </div>

      {/* Modals */}
      <LoginModal
        isOpen={activeModal === 'founder'}
        onClose={() => setActiveModal(null)}
        title="Founder Login"
        type="founder"
      />
      
      <LoginModal
        isOpen={activeModal === 'admin'}
        onClose={() => setActiveModal(null)}
        title="Admin Login"
        type="admin"
      />
      
      <LoginModal
        isOpen={activeModal === 'delegate'}
        onClose={() => setActiveModal(null)}
        title="Delegate Login"
        type="delegate"
      />
      
      <AdminRequestModal
        isOpen={activeModal === 'admin-request'}
        onClose={() => setActiveModal(null)}
      />
    </div>
  );
}
