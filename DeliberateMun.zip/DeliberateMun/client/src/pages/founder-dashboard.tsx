import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { requireAuth } from "@/lib/auth";
import { 
  Bell, 
  Users, 
  UserCheck, 
  GraduationCap, 
  Vote, 
  Check, 
  X, 
  Info,
  Watch,
  TrendingUp,
  UserPlus,
  Upload,
  Download,
  Eye,
  Settings
} from "lucide-react";

export default function FounderDashboard() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Delegate creation states
  const [singleDelegate, setSingleDelegate] = useState({
    fullName: '',
    username: '',
    password: '',
    email: '',
    country: '',
    committee: ''
  });
  const [bulkDelegates, setBulkDelegates] = useState('');
  const [showSingleModal, setShowSingleModal] = useState(false);
  const [showBulkModal, setShowBulkModal] = useState(false);

  useEffect(() => {
    if (user && !requireAuth(user.role, ['founder'])) {
      setLocation('/');
    }
  }, [user, setLocation]);

  const { data: stats } = useQuery({
    queryKey: ['/api/stats/dashboard'],
    enabled: !!user && user.role === 'founder',
  });

  const { data: adminRequests = [] } = useQuery({
    queryKey: ['/api/admin-requests'],
    enabled: !!user && user.role === 'founder',
  });

  const reviewMutation = useMutation({
    mutationFn: async ({ id, status, feedback }: { id: number; status: string; feedback?: string }) => {
      const response = await apiRequest('PATCH', `/api/admin-requests/${id}`, {
        status,
        reviewFeedback: feedback || null
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin-requests'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats/dashboard'] });
      toast({
        title: "Request Updated",
        description: "Admin request has been reviewed successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update request",
        variant: "destructive",
      });
    },
  });

  const createDelegateMutation = useMutation({
    mutationFn: async (delegateData: any) => {
      const response = await apiRequest('POST', '/api/delegates', delegateData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/delegates'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats/dashboard'] });
      toast({
        title: "Success",
        description: "Delegate created successfully",
      });
      setShowSingleModal(false);
      setSingleDelegate({
        fullName: '',
        username: '',
        password: '',
        email: '',
        country: '',
        committee: ''
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create delegate",
        variant: "destructive",
      });
    },
  });

  const bulkCreateMutation = useMutation({
    mutationFn: async (delegatesData: any[]) => {
      const promises = delegatesData.map(delegate => 
        apiRequest('POST', '/api/delegates', delegate)
      );
      return Promise.all(promises);
    },
    onSuccess: (results) => {
      queryClient.invalidateQueries({ queryKey: ['/api/delegates'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats/dashboard'] });
      toast({
        title: "Success",
        description: `${results.length} delegates created successfully`,
      });
      setShowBulkModal(false);
      setBulkDelegates('');
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create delegates in bulk",
        variant: "destructive",
      });
    },
  });

  const handleReview = (id: number, status: 'approved' | 'rejected', feedback?: string) => {
    reviewMutation.mutate({ id, status, feedback });
  };

  const handleCreateSingleDelegate = () => {
    if (!singleDelegate.fullName || !singleDelegate.username || !singleDelegate.password) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }
    
    createDelegateMutation.mutate({
      ...singleDelegate,
      userId: null, // Will be created by backend
      committeeId: 1 // Default committee
    });
  };

  const handleBulkCreate = () => {
    try {
      const lines = bulkDelegates.trim().split('\n');
      const delegates = lines.map(line => {
        const [fullName, username, password, email, country] = line.split(',').map(s => s.trim());
        return {
          fullName,
          username,
          password,
          email: email || `${username}@mun.delegate`,
          country: country || 'India',
          userId: null,
          committeeId: 1
        };
      });
      
      bulkCreateMutation.mutate(delegates);
    } catch (error) {
      toast({
        title: "Error",
        description: "Invalid CSV format. Use: Name,Username,Password,Email,Country per line",
        variant: "destructive",
      });
    }
  };

  if (!user || user.role !== 'founder') {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Access Denied</h1>
          <p className="text-muted-foreground mb-4">You don't have permission to access this page.</p>
          <Button onClick={() => setLocation('/')}>Go Home</Button>
        </div>
      </div>
    );
  }

  const pendingRequests = Array.isArray(adminRequests) ? adminRequests.filter((req: any) => req.status === 'pending') : [];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <nav className="bg-card border-b border-border px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-xl font-bold">Deliberate.in</h1>
            <span className="text-sm text-muted-foreground">MUN Voting Platform</span>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Bell className="h-5 w-5 text-muted-foreground" />
              {pendingRequests.length > 0 && (
                <span className="notification-badge">{pendingRequests.length}</span>
              )}
            </div>
            <div className="text-right">
              <p className="text-sm font-medium">{user.fullName}</p>
              <p className="text-xs text-muted-foreground">Super Admin</p>
            </div>
            <Button variant="outline" size="sm" onClick={logout}>
              Logout
            </Button>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold">Founder Dashboard</h2>
            <p className="text-muted-foreground">Platform Administration & Control</p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Pending Requests</p>
                  <p className="text-2xl font-bold text-amber-500">{(stats as any)?.pendingRequests || 0}</p>
                </div>
                <Watch className="h-5 w-5 text-amber-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Active Admins</p>
                  <p className="text-2xl font-bold text-primary">{(stats as any)?.activeAdmins || 0}</p>
                </div>
                <Users className="h-5 w-5 text-primary" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Delegates</p>
                  <p className="text-2xl font-bold text-green-500">{(stats as any)?.totalDelegates || 0}</p>
                </div>
                <GraduationCap className="h-5 w-5 text-green-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Active Sessions</p>
                  <p className="text-2xl font-bold text-green-500">{(stats as any)?.activeSessions || 0}</p>
                </div>
                <Vote className="h-5 w-5 text-green-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="requests" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="requests">Admin Requests</TabsTrigger>
            <TabsTrigger value="delegates">Delegate Management</TabsTrigger>
            <TabsTrigger value="committees">Committees</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          {/* Admin Requests Tab */}
          <TabsContent value="requests">
            <Card>
              <CardHeader>
                <CardTitle>Admin Access Requests</CardTitle>
              </CardHeader>
              <CardContent>
                {pendingRequests.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">No pending admin requests</p>
                ) : (
                  <div className="space-y-4">
                    {pendingRequests.map((request: any) => (
                      <Card key={request.id} className="bg-muted/50">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-3 mb-2">
                                <h4 className="font-semibold">{request.fullName}</h4>
                                <Badge variant="secondary" className="bg-amber-500/20 text-amber-500">
                                  PENDING
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground mb-2">{request.email}</p>
                              <p className="text-sm text-muted-foreground mb-3">
                                <strong>MUN Experience:</strong> {request.munExperience?.slice(0, 100)}...
                              </p>
                              <p className="text-sm text-muted-foreground">
                                <strong>Reason:</strong> {request.reasonForAccess?.slice(0, 100)}...
                              </p>
                            </div>
                            <div className="flex flex-col space-y-2 ml-4">
                              <Button
                                size="sm"
                                className="bg-green-600 hover:bg-green-700"
                                onClick={() => handleReview(request.id, 'approved')}
                                disabled={reviewMutation.isPending}
                              >
                                <Check className="w-4 h-4 mr-1" />
                                Approve
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleReview(request.id, 'rejected', 'Application does not meet requirements')}
                                disabled={reviewMutation.isPending}
                              >
                                <X className="w-4 h-4 mr-1" />
                                Reject
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Delegate Management Tab */}
          <TabsContent value="delegates">
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Delegate Management</h3>
                <div className="flex space-x-2">
                  <Dialog open={showSingleModal} onOpenChange={setShowSingleModal}>
                    <DialogTrigger asChild>
                      <Button className="bg-blue-600 hover:bg-blue-700">
                        <UserPlus className="w-4 h-4 mr-2" />
                        Add Single Delegate
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-md">
                      <DialogHeader>
                        <DialogTitle>Create New Delegate</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="fullName">Full Name *</Label>
                            <Input
                              id="fullName"
                              value={singleDelegate.fullName}
                              onChange={(e) => setSingleDelegate({...singleDelegate, fullName: e.target.value})}
                              placeholder="John Doe"
                            />
                          </div>
                          <div>
                            <Label htmlFor="username">Username *</Label>
                            <Input
                              id="username"
                              value={singleDelegate.username}
                              onChange={(e) => setSingleDelegate({...singleDelegate, username: e.target.value})}
                              placeholder="johndoe"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="password">Password *</Label>
                            <Input
                              id="password"
                              type="password"
                              value={singleDelegate.password}
                              onChange={(e) => setSingleDelegate({...singleDelegate, password: e.target.value})}
                              placeholder="Strong password"
                            />
                          </div>
                          <div>
                            <Label htmlFor="email">Email</Label>
                            <Input
                              id="email"
                              type="email"
                              value={singleDelegate.email}
                              onChange={(e) => setSingleDelegate({...singleDelegate, email: e.target.value})}
                              placeholder="john@example.com"
                            />
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="country">Country</Label>
                          <Input
                            id="country"
                            value={singleDelegate.country}
                            onChange={(e) => setSingleDelegate({...singleDelegate, country: e.target.value})}
                            placeholder="India"
                          />
                        </div>
                        <div className="flex justify-end space-x-2">
                          <Button variant="outline" onClick={() => setShowSingleModal(false)}>
                            Cancel
                          </Button>
                          <Button 
                            onClick={handleCreateSingleDelegate}
                            disabled={createDelegateMutation.isPending}
                          >
                            {createDelegateMutation.isPending ? "Creating..." : "Create Delegate"}
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>

                  <Dialog open={showBulkModal} onOpenChange={setShowBulkModal}>
                    <DialogTrigger asChild>
                      <Button className="bg-green-600 hover:bg-green-700">
                        <Upload className="w-4 h-4 mr-2" />
                        Bulk Import
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Bulk Create Delegates</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="bulkData">CSV Data</Label>
                          <Textarea
                            id="bulkData"
                            value={bulkDelegates}
                            onChange={(e) => setBulkDelegates(e.target.value)}
                            placeholder="Format: FullName,Username,Password,Email,Country&#10;John Doe,johndoe,password123,john@example.com,India&#10;Jane Smith,janesmith,pass456,jane@example.com,USA"
                            rows={8}
                          />
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Format: FullName,Username,Password,Email,Country (one delegate per line)
                        </div>
                        <div className="flex justify-end space-x-2">
                          <Button variant="outline" onClick={() => setShowBulkModal(false)}>
                            Cancel
                          </Button>
                          <Button 
                            onClick={handleBulkCreate}
                            disabled={bulkCreateMutation.isPending}
                          >
                            {bulkCreateMutation.isPending ? "Creating..." : "Create All Delegates"}
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>All Delegates</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-center text-muted-foreground py-8">
                    Delegate list will appear here once implemented
                  </p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Committees Tab */}
          <TabsContent value="committees">
            <Card>
              <CardHeader>
                <CardTitle>Committee Management</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-center text-muted-foreground py-8">
                  Committee management features coming soon
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics">
            <Card>
              <CardHeader>
                <CardTitle>Platform Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-center text-muted-foreground py-8">
                  Advanced analytics and reporting coming soon
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
