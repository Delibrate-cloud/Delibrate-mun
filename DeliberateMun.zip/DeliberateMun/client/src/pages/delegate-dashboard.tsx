import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { requireAuth } from "@/lib/auth";
import VotingModal from "@/components/voting/voting-modal";
import { 
  AlertTriangle,
  TrendingUp,
  Clock,
  CheckCircle,
  X,
  Minus
} from "lucide-react";

export default function DelegateDashboard() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeVotingSession, setActiveVotingSession] = useState<any>(null);

  useEffect(() => {
    if (user && !requireAuth(user.role, ['delegate'])) {
      setLocation('/');
    }
  }, [user, setLocation]);

  const { data: delegateProfile } = useQuery({
    queryKey: ['/api/delegates/me'],
    enabled: !!user && user.role === 'delegate',
  });

  const { data: votingSessions = [] } = useQuery({
    queryKey: ['/api/voting-sessions', delegateProfile?.committee?.id],
    enabled: !!delegateProfile?.committee?.id,
  });

  const castVoteMutation = useMutation({
    mutationFn: async ({ sessionId, voteType }: { sessionId: number; voteType: string }) => {
      const response = await apiRequest('POST', '/api/votes', { sessionId, voteType });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/voting-sessions'] });
      setActiveVotingSession(null);
      toast({
        title: "Vote Cast Successfully",
        description: "Your vote has been recorded",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Voting Failed",
        description: error.message || "Failed to cast vote",
        variant: "destructive",
      });
    },
  });

  if (!user || user.role !== 'delegate') {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Access Denied</h1>
          <p className="text-muted-foreground mb-4">You don't have permission to access this page.</p>
          <Button onClick={() => setLocation('/')}>Go Home</Button>
        </div>
      </div>
    );
  }

  if (!delegateProfile) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Delegate Profile Not Found</h1>
          <p className="text-muted-foreground mb-4">
            Your delegate profile could not be loaded. Please contact an administrator.
          </p>
          <Button onClick={() => setLocation('/')}>Go Home</Button>
        </div>
      </div>
    );
  }

  const activeSessions = votingSessions.filter((s: any) => s.status === 'active');
  const recentSessions = votingSessions
    .filter((s: any) => s.status === 'completed')
    .slice(0, 5);

  const handleVote = (sessionId: number, voteType: string) => {
    castVoteMutation.mutate({ sessionId, voteType });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <nav className="bg-card border-b border-border px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-xl font-bold">Deliberate.in</h1>
            <span className="text-sm text-muted-foreground">Delegate Dashboard</span>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <div className="flex items-center space-x-2">
                <span className="status-indicator status-online"></span>
                <p className="text-sm font-medium">Online</p>
              </div>
              <p className="text-xs text-muted-foreground">Session Active</p>
            </div>
            <Button variant="outline" size="sm" onClick={logout}>
              Logout
            </Button>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold">Delegate Dashboard</h2>
            <p className="text-muted-foreground">
              {delegateProfile.delegate.country} - {delegateProfile.committee.name}
            </p>
          </div>
        </div>

        {/* Active Voting Alert */}
        {activeSessions.length > 0 && (
          <Alert className="mb-6 border-amber-500/50 bg-amber-500/10">
            <AlertTriangle className="h-4 w-4 text-amber-500" />
            <AlertDescription className="flex items-center justify-between">
              <div>
                <span className="font-semibold text-amber-500">Active Voting Session</span>
                <br />
                <span className="text-amber-400">{activeSessions[0].title}</span>
              </div>
              <Button
                className="bg-amber-500 hover:bg-amber-600 text-black"
                onClick={() => setActiveVotingSession(activeSessions[0])}
              >
                Cast Vote
              </Button>
            </AlertDescription>
          </Alert>
        )}

        {/* Committee Information */}
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          <Card>
            <CardHeader>
              <CardTitle>Committee Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Committee:</span>
                <span className="font-medium">{delegateProfile.committee.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Country:</span>
                <span className="font-medium">{delegateProfile.delegate.country}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Position:</span>
                <span className="font-medium">
                  {delegateProfile.delegate.position || 'Member State'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Session:</span>
                <span className="font-medium">DUMMUN 2024</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Voting Statistics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Votes Cast:</span>
                <span className="font-medium text-green-500">
                  {delegateProfile.stats.totalVotes}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Participation Rate:</span>
                <span className="font-medium text-green-500">
                  {delegateProfile.stats.participationRate}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Active Sessions:</span>
                <span className="font-medium text-amber-500">{activeSessions.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Completed:</span>
                <span className="font-medium text-green-500">{recentSessions.length}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Voting History */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Recent Voting History</CardTitle>
          </CardHeader>
          <CardContent>
            {recentSessions.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">No voting history yet</p>
            ) : (
              <div className="space-y-4">
                {recentSessions.map((session: any) => (
                  <div
                    key={session.id}
                    className="flex items-center justify-between bg-muted/50 rounded-lg p-4"
                  >
                    <div>
                      <h4 className="font-medium">{session.title}</h4>
                      <p className="text-sm text-muted-foreground">{session.description}</p>
                    </div>
                    <div className="text-right">
                      <Badge className="bg-green-500/20 text-green-500 mb-1">
                        COMPLETED
                      </Badge>
                      <p className="text-xs text-muted-foreground">
                        {new Date(session.endTime).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Current Agenda */}
        <Card>
          <CardHeader>
            <CardTitle>Current Agenda</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {activeSessions.map((session: any, index: number) => (
                <div
                  key={session.id}
                  className="flex items-center space-x-3 p-3 bg-muted/50 rounded-lg"
                >
                  <span className="w-2 h-2 bg-amber-500 rounded-full"></span>
                  <span className="font-medium">{session.title}</span>
                  <span className="text-muted-foreground">- {session.description}</span>
                </div>
              ))}
              
              {activeSessions.length === 0 && (
                <div className="flex items-center space-x-3 p-3 bg-muted/50 rounded-lg">
                  <span className="w-2 h-2 bg-muted-foreground rounded-full"></span>
                  <span className="font-medium">No active agenda items</span>
                  <span className="text-muted-foreground">- Waiting for new sessions</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Voting Modal */}
      <VotingModal
        isOpen={!!activeVotingSession}
        onClose={() => setActiveVotingSession(null)}
        session={activeVotingSession}
        onVote={handleVote}
        isLoading={castVoteMutation.isPending}
      />
    </div>
  );
}
