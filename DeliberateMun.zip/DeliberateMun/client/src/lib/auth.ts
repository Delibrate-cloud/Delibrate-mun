export function requireAuth(userRole: string | null, allowedRoles: string[]): boolean {
  return userRole ? allowedRoles.includes(userRole) : false;
}

export function redirectByRole(role: string): string {
  switch (role) {
    case 'founder':
      return '/founder';
    case 'admin':
      return '/admin';
    case 'delegate':
      return '/delegate';
    default:
      return '/';
  }
}

export function getDisplayRole(role: string): string {
  switch (role) {
    case 'founder':
      return 'Super Admin';
    case 'admin':
      return 'Admin';
    case 'delegate':
      return 'Delegate';
    default:
      return 'User';
  }
}
